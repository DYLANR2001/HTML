function GetMap() {
//Defines the location for the center of my map using the Microsoft.Maps.Location object
  var facepunchLocation = new Microsoft.Maps.Location(51.2363, -0.5705);

  var map = new Microsoft.Maps.Map('#myMap', {
    center: facepunchLocation,
    mapTypeId: Microsoft.Maps.MapTypeId.road,
    zoom: 15,
    disableScrollWheelZoom: true,
    disablePanning: true,
    //disabled for more user friendly experience
    showLocateMeButton: false
  });

  // Create pushpin
  var pushpin = new Microsoft.Maps.Pushpin(facepunchLocation, {
    title: 'Facepunch Studios',
    subTitle: 'Address: Facepunch Studios, Waverley Ln, Farnham GU9 8EP, UK',
  });

  // Add the pushpin to the map
  map.entities.push(pushpin);

  // when the pushpin is clicked display info pops up
  Microsoft.Maps.Events.addHandler(pushpin, 'click', displayInfoBox);

  // function displaying info box
  function displayInfoBox(e) {
   
    var infobox = new Microsoft.Maps.Infobox(pushpin.getLocation(), {
      title: pushpin.getTitle(),
      description: pushpin.getSubTitle(),
      visible: false,
    });
//adds a infobox to the map
    infobox.setMap(map);
//set info box to visable
    infobox.setOptions({ visible: true });
  }
}